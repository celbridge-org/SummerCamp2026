# Laser Breakout — Game Design Document

A breakout clone, set up as a starting point for you to build on. The name hints at
the obvious first feature: a paddle that can fire laser bolts. But the direction is
yours — see TUTORIAL.md to get going.

## Core loop

- Move the paddle left/right with the mouse.
- Click to launch the ball.
- Clear all the bricks to win; the ball bounces off the paddle and walls.

## Pieces

| Piece   | Behaviour                                                            |
|---------|---------------------------------------------------------------------|
| Bird    | The paddle, now a bird; follows the mouse and can jump (UP/W) over spikes. |
| Ball    | Physics circle, constant speed, bounces off walls/paddle/bricks.    |
| Bricks  | Static grid, one colour per row; deleted when the ball hits them.   |
| Walls   | Static borders so the ball stays in play.                           |
| Lasers  | Bolts fired up from the paddle on SPACE; destroy bricks on contact.  |

## Presentation

- The game logic runs at a fixed 800x600. The canvas scales to fill the available window (q5 `displayMode('maxed')`), preserving aspect ratio so layout math is untouched.

## Lasers

- Press SPACE to fire a bolt straight up from the paddle.
- Bolts are a sensor overlap: they pass through walls/paddle but delete the first brick they touch (and themselves).
- Rate-limited by an ~0.3s cooldown so holding SPACE gives a steady stream, not a solid beam.
- A distinct sawtooth "zap" plays on fire, separate from the brick blip.

## Status

- [x] Base breakout (from template)
- [x] Fit-to-window
- [x] Lasers
- [x] Screen shake on brick break (camera jitter, eases back)
- [x] Flying bread (cosmetic loaf drifts across once a second, behind the sprites)
- [x] Oxygen meter — drains over time, refilled by shooting bricks with lasers
- [x] Tension graph — cosmetic top-right readout; random spikes scale up as oxygen falls
- [x] Potato radar — cosmetic sweeping dish in the bottom-left; occasionally pings a potato
- [x] Bread events — ball or laser touching a flying slice flashes the screen white and slides a horse across
- [x] Boss healthbar — drained by shooting bricks with lasers; baby-face bricks deal 4x damage; shows BOSS DEFEATED at zero
- [x] Peeking baby — a large baby head occasionally slides in from a side, holds, then retreats
- [x] Bird paddle — the paddle is now a bird
- [x] Spikes + jump — spikes slide along the base; press UP/W to jump them or lose oxygen (only once underway)
- [x] Out of air — when oxygen hits zero, a swarm of babies consumes the bird (game over)
- [x] Autopilot — explicit ON/OFF toggle button (bottom-right); also `window.setAutopilot(bool)` / `window.toggleAutopilot()` for an agent. While on, the bird tracks the ball, auto-fires, jumps spikes, and stays fully oxygenated (attract mode)
- [ ] Your features go here — take it somewhere else.

## Ideas to explore

- **Score and lives** — points per brick, lose a life when the ball drops past the paddle.
- **Power-ups** — bricks occasionally drop a capsule: wider paddle, multi-ball, sticky paddle.
- **Brick toughness** — some bricks take two or three hits, changing colour each time.
- **Levels** — clear the grid, load a new layout; lay bricks out in patterns.
