// breakout clone (core mechanics)
// mouse to control the paddle, click to start

const MAX_SPEED = 9;
const LASER_SPEED = 12;
const LASER_COOLDOWN = 18; // frames between shots (~0.3s at 60fps)
const OXYGEN_MAX = 100;
const OXYGEN_DRAIN = 0.07;   // oxygen lost per frame
const OXYGEN_PER_BRICK = 6;  // oxygen restored per brick shot with a laser
const TENSION_SAMPLES = 100; // points plotted on the tension graph
const BOSS_MAX = 120;
const BOSS_DMG = 1;       // boss damage per normal brick shot
const BOSS_DMG_BABY = 4;  // baby bricks hit the boss harder
const JUMP_POWER = -15;   // initial upward velocity of a jump
const GRAVITY = 0.8;      // pulls the bird back down
const SPIKE_SPEED = 4;    // how fast spikes slide along the base
const SPIKE_DAMAGE = 14;  // oxygen lost when a spike clips the bird
const WALL_THICKNESS = 30;
const BRICK_W = 40;
const BRICK_H = 20;
const BRICK_MARGIN = 4;
const ROWS = 9;
const COLUMNS = 16;
// one color per row, top to bottom
const ROW_COLORS = ['red', 'orange', 'yellow', 'green', 'cyan', 'blue', 'purple', 'magenta', 'pink'];

let paddle, ball, walls, bricks, lasers;
let laserTimer = 0;
let shake = 0; // current screen-shake intensity in pixels
let breads = []; // slices of bread flying across the screen
let oxygen = OXYGEN_MAX;
let tensionHistory = []; // recent tension readings for the (purely cosmetic) graph
let radarSweep = 0;      // radar sweep angle
let potatoes = [];       // radar potato contacts
let flash = 0;           // white screen-flash intensity (0..1)
let horses = [];         // horses sliding across the screen
let bossHP = BOSS_MAX;
let babyPeek = null;     // big baby head peeking from a side
let jumpOffset = 0;      // bird's vertical offset from rest (0 = grounded, <0 = airborne)
let jumpVel = 0;
let spikes = [];         // spikes sliding along the base
let consumed = false;    // true once the babies have devoured the bird
let babySwarm = [];      // babies closing in at game over
let baseY = 0;           // bird's resting y (set in setup)
let autopilot = false;   // toggled via the on-screen button or window.setAutopilot()
const APBTN = { x: 610, y: 560, w: 170, h: 28 }; // autopilot toggle button (bottom-right)

function setup() {
  new Canvas(800, 600);
  displayMode('maxed'); // scale the canvas to fill the window, preserving aspect ratio

  // four static walls, same geometry as the original
  walls = new Group();
  walls.collider = 'static';
  walls.visible = true; // they sit just off-canvas anyway
  new walls.Sprite(canvas.w / 2, -WALL_THICKNESS / 2, canvas.w + WALL_THICKNESS * 2, WALL_THICKNESS);
  new walls.Sprite(canvas.w / 2, canvas.h + WALL_THICKNESS / 2, canvas.w + WALL_THICKNESS * 2, WALL_THICKNESS);
  new walls.Sprite(-WALL_THICKNESS / 2, canvas.h / 2, WALL_THICKNESS, canvas.h);
  new walls.Sprite(canvas.w + WALL_THICKNESS / 2, canvas.h / 2, WALL_THICKNESS, canvas.h);

  paddle = new Sprite(canvas.w / 2, canvas.h - 50, 100, 10);
  paddle.collider = 'kinematic'; // moved by code, immovable by collisions
  paddle.color = color(247, 134, 131); // blend the bar into the background; the bird stands in for it
  paddle.text = '\uD83D\uDC26';         // the paddle is now a bird
  paddle.textSize = 48;
  baseY = canvas.h - 50;                // the bird's resting height

  bricks = new Group();
  bricks.collider = 'static';
  let offsetX = canvas.w / 2 - (COLUMNS - 1) * (BRICK_MARGIN + BRICK_W) / 2;
  let offsetY = 80;
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLUMNS; c++) {
      let brick = new bricks.Sprite(offsetX + c * (BRICK_W + BRICK_MARGIN), offsetY + r * (BRICK_H + BRICK_MARGIN), BRICK_W, BRICK_H);
      brick.color = ROW_COLORS[r];
      if (random() < 0.13) { // some bricks look like babies
        brick.isBaby = true;
        brick.text = '\uD83D\uDC76';
        brick.textSize = 14;
      }
    }
  }

  ball = new Sprite(canvas.w / 2, canvas.h - 200, 11); // single size = circle
  ball.color = 'white';
  ball.bounciness = 1;   
  ball.friction = 0;
  ball.rotationLock = true;

  // register the brick callback once; applies forever
  ball.collides(bricks, brickHit);

  // laser bolts fired from the paddle
  lasers = new Group();
  lasers.collider = 'dynamic'; // dynamic so it can move and generate contacts
  lasers.color = 'lime';
  lasers.w = 4;
  lasers.h = 16;
  lasers.overlaps(allSprites);       // pass through everything (no push, no blocking)
  lasers.overlaps(bricks, laserHit); // ...but destroy bricks on contact
}

function update() {
    clear();

  // game over: the babies have eaten the bird — just animate the swarm closing in
  if (consumed) {
    for (let b of babySwarm) {
      b.x = lerp(b.x, paddle.x, 0.05);
      b.y = lerp(b.y, paddle.y, 0.05);
    }
    return;
  }

  // toggle autopilot when its on-screen button is clicked
  let pressed = mouse.presses();
  let onButton = pressed && mouse.x > APBTN.x && mouse.x < APBTN.x + APBTN.w && mouse.y > APBTN.y && mouse.y < APBTN.y + APBTN.h;
  if (onButton) autopilot = !autopilot;

  // steer the bird: toward the mouse, or toward the ball while on autopilot
  let targetX = constrain(autopilot ? ball.x : mouse.x, paddle.w / 2, canvas.w - paddle.w / 2);
  let wantJump = kb.presses('up') || kb.presses('w');
  if (autopilot && jumpOffset === 0) {
    for (let s of spikes) { // hop an approaching spike
      if (abs(s.x + s.vx * 8 - paddle.x) < paddle.w / 2 + 20) { wantJump = true; break; }
    }
  }
  if (wantJump && jumpOffset === 0) jumpVel = JUMP_POWER;
  if (jumpVel !== 0 || jumpOffset < 0) {
    jumpVel += GRAVITY;
    jumpOffset = min(0, jumpOffset + jumpVel);
    if (jumpOffset === 0) jumpVel = 0;
  }
  paddle.moveTowards(targetX, baseY + jumpOffset, 1);

  // launch
  if (((pressed && !onButton) || autopilot) && ball.speed == 0) {
    ball.speed = MAX_SPEED;
    ball.direction = random(80, 100); // roughly downward
  }

  // paddle english
  if (ball.collides(paddle)) {
    let swing = (ball.x - paddle.x) / 3;
    ball.direction += swing;
    ball.speed = MAX_SPEED;
  }

  // keep speed constant (Box2D can add tiny energy on bounces)
  if (ball.speed > 0) ball.speed = MAX_SPEED;

  // oxygen: autopilot keeps the bird breathing; otherwise it drains once underway
  if (autopilot) {
    oxygen = OXYGEN_MAX;
  } else if (ball.speed > 0) {
    oxygen = max(0, oxygen - OXYGEN_DRAIN);
    if (oxygen === 0 && !consumed) startConsume(); // out of air: the babies move in
  }

  // tension graph data: random jitter, amplitude grows as oxygen falls (does nothing)
  let tensionFactor = map(oxygen, 0, OXYGEN_MAX, 1, 0.15);
  tensionHistory.push(random(0, tensionFactor));
  if (tensionHistory.length > TENSION_SAMPLES) tensionHistory.shift();

  // radar sweep + occasional potato contacts (cosmetic)
  radarSweep += 0.04;
  if (random() < 0.012) potatoes.push({ angle: random(TWO_PI), dist: random(0.2, 0.92), life: 1 });
  for (let i = potatoes.length - 1; i >= 0; i--) {
    potatoes[i].life -= 0.006;
    if (potatoes[i].life <= 0) potatoes.splice(i, 1);
  }

  // fire lasers on space, rate-limited by a cooldown
  if (laserTimer > 0) laserTimer--;
  if ((kb.pressing('space') || autopilot) && laserTimer === 0) {
    fireLaser();
    laserTimer = LASER_COOLDOWN;
  }

  // remove bolts that have flown off the top of the screen
  for (let bolt of lasers) {
    if (bolt.y < -bolt.h) bolt.delete();
  }

  // screen shake: jitter the camera off-center, then ease it back
  if (shake > 0) {
    camera.x = canvas.w / 2 + random(-shake, shake);
    camera.y = canvas.h / 2 + random(-shake, shake);
    shake *= 0.85; // decay
    if (shake < 0.4) { shake = 0; camera.x = canvas.w / 2; camera.y = canvas.h / 2; }
  }

  // toss a slice of bread across the screen once a second
  if (frameCount % 60 === 0) {
    let fromLeft = random() < 0.5;
    breads.push({
      x: fromLeft ? -40 : canvas.w + 40,
      y: random(60, canvas.h - 60),
      vx: (fromLeft ? 1 : -1) * random(3, 6),
      rot: random(TWO_PI),
      vr: random(-0.1, 0.1)
    });
  }
  // move the bread; a ball or laser touching a slice triggers a flash and a horse
  for (let i = breads.length - 1; i >= 0; i--) {
    let b = breads[i];
    b.x += b.vx;
    b.rot += b.vr;

    let hit = dist(b.x, b.y, ball.x, ball.y) < 28;
    if (!hit) {
      for (let bolt of lasers) {
        if (dist(b.x, b.y, bolt.x, bolt.y) < 24) { hit = true; bolt.delete(); break; }
      }
    }
    if (hit) {
      breads.splice(i, 1);
      flash = 1;          // flash the screen white
      spawnHorse();       // and send a horse sliding through
      continue;
    }

    if (b.x < -60 || b.x > canvas.w + 60) breads.splice(i, 1);
  }

  // slide horses across, then off the right edge
  for (let i = horses.length - 1; i >= 0; i--) {
    horses[i].x += horses[i].vx;
    if (horses[i].x > canvas.w + 100) horses.splice(i, 1);
  }
  // fade the flash back out
  if (flash > 0) flash = max(0, flash - 0.05);

  // spikes slide along the base; the bird must jump them or lose a chunk of oxygen (only once underway)
  if (ball.speed > 0 && random() < 0.006) {
    let fromLeft = random() < 0.5;
    spikes.push({ x: fromLeft ? -20 : canvas.w + 20, vx: (fromLeft ? 1 : -1) * SPIKE_SPEED });
  }
  for (let i = spikes.length - 1; i >= 0; i--) {
    let s = spikes[i];
    s.x += s.vx;
    // clipped if the bird is overhead and hasn't jumped high enough
    if (abs(paddle.x - s.x) < paddle.w / 2 + 14 && paddle.y > baseY - 35) {
      if (!autopilot) { // autopilot is immune to spikes
        oxygen = max(0, oxygen - SPIKE_DAMAGE);
        if (oxygen === 0 && !consumed) startConsume();
      }
      addShake(10);
      spikes.splice(i, 1);
      continue;
    }
    if (s.x < -40 || s.x > canvas.w + 40) spikes.splice(i, 1);
  }

  // a big baby head occasionally peeks in from a side, holds, then retreats
  if (!babyPeek && random() < 0.006) {
    babyPeek = { side: random() < 0.5 ? -1 : 1, y: random(150, canvas.h - 150), prog: 0, dir: 1, hold: 0 };
  }
  if (babyPeek) {
    if (babyPeek.dir === 1) {
      babyPeek.prog = min(1, babyPeek.prog + 0.04);
      if (babyPeek.prog === 1 && ++babyPeek.hold > 45) babyPeek.dir = -1;
    } else {
      babyPeek.prog -= 0.04;
      if (babyPeek.prog <= 0) babyPeek = null;
    }
  }
}

function draw() {
  background(lerpColor(color(247, 134, 131), color(255), flash)); // flashes white on a bread hit

  // controls hint at the top
  push();
  fill('white');
  textAlign(CENTER, TOP);
  textSize(16);
  text('Click to start  -  steer with mouse  -  SPACE shoots  -  UP jumps', canvas.w / 2, 10);
  pop();

  // oxygen meter (top-left): drains over time, refilled by shooting bricks
  push();
  let barW = 200, barH = 16, bx = 20, by = 32;
  noStroke();
  fill(0, 0, 0, 120);
  rect(bx, by, barW, barH);
  fill(oxygen < 25 ? color(220, 60, 60) : color(60, 200, 230));
  rect(bx, by, barW * oxygen / OXYGEN_MAX, barH);
  noFill();
  stroke(255);
  rect(bx, by, barW, barH);
  noStroke();
  fill('white');
  textAlign(LEFT, CENTER);
  textSize(14);
  text('O2', bx + barW + 8, by + barH / 2);
  pop();

  // tension graph (top-right): random spikes, bigger when oxygen is low. Purely cosmetic.
  push();
  let gw = 180, gh = 40, gx = canvas.w - gw - 20, gy = 24;
  noStroke();
  fill(0, 0, 0, 120);
  rect(gx, gy, gw, gh);
  stroke(230, 70, 70);
  strokeWeight(2);
  noFill();
  beginShape();
  for (let i = 0; i < tensionHistory.length; i++) {
    let gxPt = gx + (i / (TENSION_SAMPLES - 1)) * gw;
    let gyPt = gy + gh - tensionHistory[i] * gh;
    vertex(gxPt, gyPt);
  }
  endShape();
  stroke(255);
  strokeWeight(1);
  noFill();
  rect(gx, gy, gw, gh);
  pop();

  // radar (bottom-left): sweeps and occasionally pings a potato. Cosmetic.
  push();
  let rcx = 90, rcy = canvas.h - 90, rr = 60;
  noStroke();
  fill(0, 35, 0, 200);
  circle(rcx, rcy, rr * 2);
  stroke(90, 220, 90, 200);
  strokeWeight(1);
  noFill();
  circle(rcx, rcy, rr * 2);
  circle(rcx, rcy, rr * 1.33);
  circle(rcx, rcy, rr * 0.66);
  line(rcx - rr, rcy, rcx + rr, rcy);
  line(rcx, rcy - rr, rcx, rcy + rr);
  stroke(140, 255, 140);
  strokeWeight(2);
  line(rcx, rcy, rcx + cos(radarSweep) * rr, rcy + sin(radarSweep) * rr);
  for (let p of potatoes) {
    let px = rcx + cos(p.angle) * p.dist * rr;
    let py = rcy + sin(p.angle) * p.dist * rr;
    noFill();
    stroke(140, 255, 140, p.life * 255);
    strokeWeight(1);
    circle(px, py, (1 - p.life) * 18 + 6);
    noStroke();
    textAlign(CENTER, CENTER);
    textSize(15);
    text('\uD83E\uDD54', px, py); // potato emoji
  }
  pop();

  // spikes sliding along the base of the screen
  push();
  noStroke();
  fill(190, 30, 30);
  for (let s of spikes) {
    triangle(s.x - 16, canvas.h - 6, s.x + 16, canvas.h - 6, s.x, canvas.h - 48);
  }
  pop();

  // draw the flying bread
  push();
  textAlign(CENTER, CENTER);
  textSize(40);
  for (let b of breads) {
    push();
    translate(b.x, b.y);
    rotate(b.rot);
    text('\uD83C\uDF5E', 0, 0); // bread emoji
    pop();
  }
  pop();

  // draw any sliding horses
  push();
  textAlign(CENTER, CENTER);
  textSize(70);
  for (let h of horses) {
    text('\uD83D\uDC34', h.x, h.y); // horse emoji
  }
  pop();

  // boss healthbar (top center): drained by shooting bricks
  push();
  let bw = 320, bh = 16, bbx = canvas.w / 2 - bw / 2, bby = 50;
  noStroke();
  fill(0, 0, 0, 140);
  rect(bbx, bby, bw, bh);
  fill(200, 40, 40);
  rect(bbx, bby, bw * bossHP / BOSS_MAX, bh);
  noFill();
  stroke(255);
  strokeWeight(1);
  rect(bbx, bby, bw, bh);
  noStroke();
  fill('white');
  textAlign(CENTER, BOTTOM);
  textSize(13);
  text(bossHP > 0 ? 'BOSS' : 'BOSS DEFEATED', canvas.w / 2, bby - 2);
  pop();

  // big baby head peeking from a side
  if (babyPeek) {
    push();
    textAlign(CENTER, CENTER);
    textSize(130);
    let px = babyPeek.side === -1
      ? lerp(-80, 60, babyPeek.prog)
      : lerp(canvas.w + 80, canvas.w - 60, babyPeek.prog);
    text('\uD83D\uDC76', px, babyPeek.y); // baby emoji
    pop();
  }

  // autopilot toggle button (bottom-right)
  push();
  noStroke();
  fill(autopilot ? color(60, 180, 90) : color(70, 70, 70));
  rect(APBTN.x, APBTN.y, APBTN.w, APBTN.h, 6);
  noFill();
  stroke(255);
  rect(APBTN.x, APBTN.y, APBTN.w, APBTN.h, 6);
  noStroke();
  fill('white');
  textAlign(CENTER, CENTER);
  textSize(14);
  text('AUTOPILOT: ' + (autopilot ? 'ON' : 'OFF'), APBTN.x + APBTN.w / 2, APBTN.y + APBTN.h / 2);
  pop();

  // autopilot indicator
  if (autopilot && !consumed) {
    push();
    fill(0, 0, 0, 150);
    textAlign(CENTER, CENTER);
    textSize(20);
    text('AUTOPILOT', canvas.w / 2, canvas.h - 110);
    pop();
  }

  // game over: the babies swarm in and devour the bird
  if (consumed) {
    push();
    textAlign(CENTER, CENTER);
    for (let b of babySwarm) {
      textSize(b.s);
      text('\uD83D\uDC76', b.x, b.y);
    }
    fill(0);
    textSize(34);
    text('THE BABIES CONSUMED THE BIRD', canvas.w / 2, canvas.h / 2 - 40);
    textSize(15);
    text('(reload to try again)', canvas.w / 2, canvas.h / 2 - 8);
    pop();
  }
}

function laserHit(laser, brick) {
  bossHP = max(0, bossHP - (brick.isBaby ? BOSS_DMG_BABY : BOSS_DMG)); // shooting bricks hurts the boss
  brick.delete();
  laser.delete();
  playBlip();
  addShake(5);
  oxygen = min(OXYGEN_MAX, oxygen + OXYGEN_PER_BRICK); // shooting bricks restores air
}

// bump the shake intensity; strongest recent impact wins
function addShake(amount) {
  if (amount > shake) shake = amount;
}

function spawnHorse() {
  horses.push({ x: -90, y: random(canvas.h * 0.45, canvas.h * 0.75), vx: random(12, 18) });
}

// oxygen hit zero: hide the bird and send the babies in to consume it
function startConsume() {
  consumed = true;
  ball.speed = 0;
  ball.visible = false;
  bricks.visible = false;
  paddle.visible = false;
  for (let i = 0; i < 16; i++) {
    babySwarm.push({ x: random(canvas.w), y: random(-80, canvas.h), s: random(44, 84) });
  }
}

function fireLaser() {
  let bolt = new lasers.Sprite(paddle.x, paddle.y - paddle.h);
  bolt.vel.y = -LASER_SPEED; // travel straight up
  playZap();
}

function brickHit(ball, brick) {
  brick.delete();
  playBlip();
  addShake(5);
}

// short synthesized "blip" via the Web Audio API (no sound file needed)
let audioCtx;
function playBlip() {
  if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  if (audioCtx.state === 'suspended') audioCtx.resume();

  let osc = audioCtx.createOscillator();
  let gain = audioCtx.createGain();
  osc.type = 'square';
  osc.frequency.value = 440;

  let now = audioCtx.currentTime;
  gain.gain.setValueAtTime(0.2, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1); // quick fade out

  osc.connect(gain);
  gain.connect(audioCtx.destination);
  osc.start(now);
  osc.stop(now + 0.1);
}

// quick descending "zap" for the laser, distinct from the brick blip
function playZap() {
  if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  if (audioCtx.state === 'suspended') audioCtx.resume();

  let osc = audioCtx.createOscillator();
  let gain = audioCtx.createGain();
  osc.type = 'sawtooth';

  let now = audioCtx.currentTime;
  osc.frequency.setValueAtTime(880, now);
  osc.frequency.exponentialRampToValueAtTime(220, now + 0.12);
  gain.gain.setValueAtTime(0.15, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

  osc.connect(gain);
  gain.connect(audioCtx.destination);
  osc.start(now);
  osc.stop(now + 0.12);
}

// expose autopilot control so an agent can drive it: window.setAutopilot(true)
window.setAutopilot = function (on) { autopilot = !!on; return autopilot; };
window.toggleAutopilot = function () { autopilot = !autopilot; return autopilot; };
